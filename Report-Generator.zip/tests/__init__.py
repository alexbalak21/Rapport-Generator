# tests package initializer
